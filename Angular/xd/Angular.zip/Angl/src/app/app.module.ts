import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FirstComponent } from './first/first.component';
import { ExampleComponent } from './example/example.component';
import { MaterialModule } from './material/material.module';
import { ContactListComponent } from './contact-list/contact-list.component';
import { MatToolbarModule } from '@angular/material/toolbar';
import { Zadanie1Component } from './zadanie1/zadanie1.component';
import { Zad1Component } from './zad1/zad1.component';

@NgModule({
  declarations: [
    AppComponent,
    FirstComponent,
    ExampleComponent,
    ContactListComponent,
    Zadanie1Component,
    Zad1Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MaterialModule,
    MatToolbarModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
