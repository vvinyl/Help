import { Component, OnInit } from '@angular/core';
import { Contact, Sex } from '../Model/contact';
import { Email } from '../Model/email';

@Component({
  selector: 'app-contact-list',
  standalone: false,
  
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.css'],
  styles: ['.icon{width:50px; height:50px, border-radius:25px}']
})
export class ContactListComponent implements OnInit{
  contacts: Contact[];
  Sex = Sex;
  isListShown: boolean;
  title: string;

  constructor(){
    this.contacts = [];
    this.isListShown = true;
    this.title = "Ukryj listę"
  }

  ngOnInit():void{
    try {
      this.contacts.push(
        new Contact(1, "Ala", "Kot", Sex.Female, [new Email("ala.kot@przyklad.pl", { id: 1, name: "Work" })], 23),
        new Contact(2, "Tomasz", "Nowak", Sex.Male, [new Email("tomasz.nowak@przyklad.pl", { id: 2, name: "Personal" })], 34),
        new Contact(3, "Cezary", "Adamski", Sex.Male, [new Email("cezary.adamski@przyklad.pl", { id: 3, name: "Other" })], 45)
      );
    } catch (error) {
      console.error("Błąd podczas inicjalizacji kontaktów:", error);
    }    
  }

  onClick(){
    this.isListShown = !this.isListShown;
    this.title = this.isListShown ? "Ukryj listę" : "Pokaż listę"
  }
}
