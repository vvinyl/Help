import { Component } from '@angular/core';

@Component({
  selector: 'zadanie1',
  standalone: false,
  
  templateUrl: './zadanie1.component.html',
  styleUrl: './zadanie1.component.css'
})
export class Zadanie1Component {
  text:string = ""
  constructor() {

  }

  clickHandle(){
    this.text = "KP";
  }
}
