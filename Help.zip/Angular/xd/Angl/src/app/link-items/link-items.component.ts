import { Component } from '@angular/core';

@Component({
  selector: 'app-link-items',
  standalone: false,
  
  templateUrl: './link-items.component.html',
  styleUrl: './link-items.component.css'
})
export class LinkItemsComponent {

}
