import { Component } from '@angular/core';

@Component({
  selector: 'app-zad1',
  standalone: false,
  
  templateUrl: './zad1.component.html',
  styleUrl: './zad1.component.css'
})
export class Zad1Component {

}
