import { Component } from '@angular/core';

@Component({
  selector: 'zadanie1',
  standalone: false,
  
  templateUrl: './zadanie1.component.html',
  styleUrl: './zadanie1.component.css'
})
export class Zadanie1Component {
  // zad 1
  text:string = "Pierwotny tekst"
  // zad 1
  clickHandle(){
    this.text = "KP"
  }

  // zad 2
  fontSizeClass:string = '';
  textStyleClass:string = '';
  // zad 2
  changeFont():void{
    this.fontSizeClass='largeFont';
    this.textStyleClass = '';
  }
  changeTextStyle():void{
    this.textStyleClass = 'greenLinethrough';
    this.fontSizeClass = ''; // Usunięcie innych klas
  }

  // zad 3
  text3:string = "abcd";
  bothStyle:string = ""
  // zad 3
  clickHandle3(){
    this.text3 = "VVinyl";
  }
  changeStyle3():void{
    this.bothStyle = "both";
  }

  // zad 4
  text4:string = "example";
  isLargeFont: boolean = false;
  isGreen: boolean = false;

  clickHandle4():void{
    this.text4 === "example" ? this.text4="VVINYL" : this.text4 = "example";
  }
  changeFont4():void{
    this.isLargeFont = !this.isLargeFont;
  }
  changeColor4():void{
    this.isGreen = !this.isGreen;
  }

  
  constructor() {

  }  
}
