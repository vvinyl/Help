import { Component } from '@angular/core';

@Component({
  selector: 'app-zadanie78',
  standalone: false,
  
  templateUrl: './zadanie78.component.html',
  styleUrl: './zadanie78.component.css'
})
export class Zadanie78Component {
  value:number = 0;

  onClick(newValue:number){
    this.value = newValue;
  }

}
