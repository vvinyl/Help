import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <mat-toolbar>
    <span>Lista kontaktów</span>
  </mat-toolbar>
  <div>
    <app-contact-list></app-contact-list>
  </div>
  <div>
    <zadanie1></zadanie1>
  </div>
  <div>
    <app-zadanie56></app-zadanie56>
  </div>
  <div>
    <app-zadanie78></app-zadanie78>
  </div>
  `,
  standalone: false,
  styles: []
})
export class AppComponent {
  title = 'Contacts';
}
