import { Component } from '@angular/core';

interface Link {
  id:number;
  name:string;
  url:string;
  isActive: boolean;
}

interface Link2 {
  id:number;
  name:string;
  url:string;
  isActive: boolean;
}

@Component({
  selector: 'app-zadanie56',
  standalone: false,
  
  templateUrl: './zadanie56.component.html',
  styleUrl: './zadanie56.component.css'
})
export class Zadanie56Component {
  // !!!!!!!!!!! TYLKO WIELOKROTNY WYBÓR
  links:Link[]=[
    {id: 1, name: "FACEBOOK", url: "facebook.com", isActive:false},
    {id: 2, name: "INSTAGRAM", url: "instagram.com", isActive:false},
    {id: 3, name: "X", url: "x.com", isActive:false},
  ]
  
  links2:Link[]=[
    {id: 1, name: "FACEBOOK", url: "facebook.com", isActive:false},
    {id: 2, name: "INSTAGRAM", url: "instagram.com", isActive:false},
    {id: 3, name: "X", url: "x.com", isActive:false},
  ]

  toggleLink(link:Link){
    link.isActive = !link.isActive;
  }

}
