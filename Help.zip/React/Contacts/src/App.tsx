import './App.css'
import { Zadanie1 } from './components/Zadanie1'
import { Zadanie2 } from './components/Zadanie2'
import { Zadanie3 } from './components/Zadanie3'
import { Zadanie45 } from './components/Zadanie45'
import { Zadanie678 } from './components/Zadanie678'

function App() {
  return (
    <>
      <Zadanie1/>
      <Zadanie2/>
      <Zadanie3/>
      <Zadanie45/>
      <Zadanie678/>
    </>
  )
}

export default App
