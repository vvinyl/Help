import './App.css'
import Zadanie1 from './Components/Zadanie1/Zadanie1'
import Zadanie2 from './Components/Zadanie2/Zadanie2'
import Zadanie3 from './Components/Zadanie3/Zadanie3'
import Zadanie4 from './Components/Zadanie4/Zadanie4'
import Zadanie5 from './Components/Zadanie5/Zadanie5'

function App() {

  return (
    <>
      <Zadanie1 />
      <Zadanie2 />
      <Zadanie3  />
      <Zadanie4  />
      <Zadanie5  />
    </>
  )
}

export default App
